import { useCallback, useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import { socket } from '../lib/ws';
import { useSession } from '../App';
import { BET_LABELS, payoutLabel, type BetType, type Bets, type Card, type LeaderboardEntry, type TableSnapshot } from '../lib/protocol';
import { RoadmapPanel } from '../components/Roadmap';
import { LiveVideo } from '../components/LiveVideo';
import { useCountdown, PHASE_LABEL } from '../lib/useCountdown';

const CHIPS = [10, 50, 100, 500, 1000, 5000];
const MAIN: BetType[] = ['player', 'tie', 'banker'];
const SIDE: BetType[] = ['playerPair', 'anyPair', 'perfectPair', 'bankerPair', 'lucky6', 'lucky7', 'big', 'small'];

export function TablePage() {
  const { id = '' } = useParams();
  const { user } = useSession();
  const [table, setTable] = useState<TableSnapshot | null>(null);
  const [confirmed, setConfirmed] = useState<Bets>({});   // 服务端已接受的本局注码
  const [pending, setPending] = useState<Bets>({});       // 本地待提交
  const [chip, setChip] = useState(100);
  const [toast, setToast] = useState<string>('');
  const [lastSettle, setLastSettle] = useState<number | null>(null);
  const secs = useCountdown(table?.countdownEndsAt);

  const flash = useCallback((m: string) => { setToast(m); setTimeout(() => setToast(''), 2500); }, []);

  useEffect(() => {
    socket.subscribe(id);
    const off = socket.on((m) => {
      if (m.tableId && m.tableId !== id && m.table?.id !== id) return;
      switch (m.type) {
        case 'table:state':
          setTable((prev) => {
            if (m.myBets) setConfirmed(m.myBets);
            else if (prev && prev.roundId !== m.table.roundId) { setConfirmed({}); setPending({}); } // 新一局：清空注码
            return m.table;
          });
          break;
        case 'table:card':
          setTable((t) => t && ({
            ...t,
            playerCards: m.side === 'player' ? [...t.playerCards, m.card] : t.playerCards,
            bankerCards: m.side === 'banker' ? [...t.bankerCards, m.card] : t.bankerCards,
            playerTotal: m.playerTotal, bankerTotal: m.bankerTotal, phase: 'dealing',
          }));
          break;
        case 'table:result':
          setTable((t) => t && ({ ...t, lastResult: m.result, roadmap: m.roadmap, phase: 'settling' }));
          break;
        case 'table:bets':
          setTable((t) => t && ({ ...t, leaderboard: m.leaderboard }));
          break;
        case 'bet:ok':
          setConfirmed(m.bets); setPending({});
          break;
        case 'settled': {
          const net = (m.settlements as any[]).reduce((s, x) => s + x.net, 0);
          setLastSettle(net);
          setTimeout(() => setLastSettle(null), 4000);
          break;
        }
        case 'error':
          flash(m.message);
          setPending({});
          break;
      }
    });
    return () => { off(); socket.unsubscribe(id); };
  }, [id, flash]);

  const betting = table?.phase === 'betting' && secs > 0;
  const total = (b: Bets) => Object.values(b).reduce((s, v) => s + (v ?? 0), 0);

  const addChip = (t: BetType) => {
    if (!betting) return;
    setPending((p) => ({ ...p, [t]: (p[t] ?? 0) + chip }));
  };
  const submit = () => { if (total(pending) > 0) socket.send({ type: 'bet', tableId: id, bets: pending }); };
  const clearAll = () => { setPending({}); if (total(confirmed) > 0) socket.send({ type: 'clearBets', tableId: id }); };
  const rebet = () => { if (betting && lastBets) setPending(lastBets); };
  const [lastBets, setLastBets] = useState<Bets | null>(null);
  useEffect(() => { if (table?.phase === 'dealing' && total(confirmed) > 0) setLastBets(confirmed); }, [table?.phase]); // eslint-disable-line

  const shown = useMemo(() => {
    const out: Bets = { ...confirmed };
    for (const [k, v] of Object.entries(pending)) out[k as BetType] = (out[k as BetType] ?? 0) + (v ?? 0);
    return out;
  }, [confirmed, pending]);

  if (!table) return <div className="center muted">连接牌桌…</div>;
  const r = table.lastResult;
  const showResult = table.phase === 'settling' && r;

  return (
    <div className={`table-page ${table.kind}`}>
      <header className="topbar">
        <Link to="/" className="ghost">‹ 返回大厅</Link>
        <div className="brand">{table.name} <span className="muted small">#{table.shoeId} 第 {table.roundNo} 局</span></div>
        <div className="userbar">
          <span>{user?.nickname}</span>
          <span className="balance">¥ {user?.balance.toLocaleString()}</span>
        </div>
      </header>

      <div className="stage">
        <div className="scene">
          {table.kind === 'live'
            ? <LiveVideo whepUrl={table.stream?.whepUrl} dealerName={table.dealerName} />
            : <div className="rng-felt"><div className="muted">RNG 自动派牌 · 牌靴 {table.shoeId}</div></div>}

          <div className="hands">
            <Hand side="player" cards={table.playerCards} total={table.playerTotal} win={showResult ? r!.outcome === 'player' : false} />
            <div className="phase-box">
              <div className={`phase ${table.phase}`}>{betting ? `投注 ${secs}s` : PHASE_LABEL[table.phase]}</div>
              {showResult && <div className={`outcome ${r!.outcome}`}>{r!.outcome === 'banker' ? '庄赢' : r!.outcome === 'player' ? '闲赢' : '和局'}</div>}
              {lastSettle !== null && <div className={`settle ${lastSettle >= 0 ? 'win' : 'lose'}`}>{lastSettle >= 0 ? '+' : ''}{lastSettle.toLocaleString()}</div>}
            </div>
            <Hand side="banker" cards={table.bankerCards} total={table.bankerTotal} win={showResult ? r!.outcome === 'banker' : false} />
          </div>
        </div>

        <aside className="players">
          <div className="panel-title">玩家押注 / 输赢 <span className="muted small">按流水排序 · 在线 {table.playersOnline}</span></div>
          <Leaderboard rows={table.leaderboard} me={user?.id} />
        </aside>
      </div>

      <div className="bet-area">
        <div className="bet-grid">
          <div className="side-row">
            {SIDE.slice(0, 4).map((t) => <BetSpot key={t} t={t} table={table} amount={shown[t]} onClick={() => addChip(t)} disabled={!betting} />)}
          </div>
          <div className="main-row">
            {MAIN.map((t) => <BetSpot key={t} t={t} table={table} amount={shown[t]} onClick={() => addChip(t)} disabled={!betting} big />)}
          </div>
          <div className="side-row">
            {SIDE.slice(4).map((t) => <BetSpot key={t} t={t} table={table} amount={shown[t]} onClick={() => addChip(t)} disabled={!betting} />)}
          </div>
        </div>
        <div className="chips">
          {CHIPS.map((c) => <button key={c} className={`chip c${c} ${chip === c ? 'sel' : ''}`} onClick={() => setChip(c)}>{c >= 1000 ? `${c / 1000}K` : c}</button>)}
          <div className="actions">
            <button onClick={rebet} disabled={!betting || !lastBets} className="ghost">重复</button>
            <button onClick={clearAll} disabled={!betting || total(shown) === 0} className="ghost">清除</button>
            <button onClick={submit} disabled={!betting || total(pending) === 0} className="primary">确认 ¥{total(pending).toLocaleString()}</button>
          </div>
          <div className="muted small">限红 {table.limits.minBet} – {table.limits.maxBet.toLocaleString()} · 边注上限 {table.limits.maxSideBet.toLocaleString()}</div>
        </div>
      </div>

      <RoadmapPanel rm={table.roadmap} />
      {toast && <div className="toast">{toast}</div>}
    </div>
  );
}

function BetSpot({ t, table, amount, onClick, disabled, big }: { t: BetType; table: TableSnapshot; amount?: number; onClick: () => void; disabled: boolean; big?: boolean }) {
  const r = table.lastResult;
  const hit = table.phase === 'settling' && r ? isWinning(t, r) : false;
  return (
    <button className={`spot ${t} ${big ? 'main-spot' : ''} ${hit ? 'hit' : ''}`} onClick={onClick} disabled={disabled}>
      <span className="spot-name">{BET_LABELS[t]}</span>
      <span className="spot-odds">{payoutLabel(t, table.payouts)}</span>
      {amount ? <span className="spot-amount">{amount.toLocaleString()}</span> : null}
    </button>
  );
}

function isWinning(t: BetType, r: NonNullable<TableSnapshot['lastResult']>): boolean {
  const n = r.playerCardCount + r.bankerCardCount;
  switch (t) {
    case 'player': return r.outcome === 'player';
    case 'banker': return r.outcome === 'banker';
    case 'tie': return r.outcome === 'tie';
    case 'playerPair': return r.playerPair;
    case 'bankerPair': return r.bankerPair;
    case 'anyPair': return r.playerPair || r.bankerPair;
    case 'perfectPair': return (r.playerPair && r.playerCards[0].suit === r.playerCards[1].suit) || (r.bankerPair && r.bankerCards[0].suit === r.bankerCards[1].suit);
    case 'lucky6': return r.outcome === 'banker' && r.bankerTotal === 6;
    case 'lucky7': return r.outcome === 'banker' && r.bankerTotal === 7;
    case 'big': return n >= 5;
    case 'small': return n === 4;
  }
}

function Hand({ side, cards, total, win }: { side: 'player' | 'banker'; cards: Card[]; total: number; win: boolean }) {
  return (
    <div className={`hand ${side} ${win ? 'win' : ''}`}>
      <div className="hand-title">{side === 'player' ? '闲 PLAYER' : '庄 BANKER'} <b>{cards.length ? total : ''}</b></div>
      <div className="cards">
        {cards.map((c, i) => <PlayingCard key={i} c={c} rotated={i === 2} />)}
        {cards.length === 0 && <div className="card-slot" />}
      </div>
    </div>
  );
}

const SUIT: Record<string, string> = { S: '♠', H: '♥', D: '♦', C: '♣' };
function PlayingCard({ c, rotated }: { c: Card; rotated?: boolean }) {
  const red = c.suit === 'H' || c.suit === 'D';
  const rank = c.rank === 'T' ? '10' : c.rank;
  return (
    <div className={`card ${red ? 'red' : ''} ${rotated ? 'rot' : ''}`}>
      <span className="rank">{rank}</span><span className="suit">{SUIT[c.suit]}</span>
    </div>
  );
}

function Leaderboard({ rows, me }: { rows: LeaderboardEntry[]; me?: number }) {
  if (!rows.length) return <div className="muted small pad">暂无玩家下注</div>;
  return (
    <table className="lb">
      <thead><tr><th>#</th><th>玩家</th><th>本局押注</th><th>流水</th><th>输赢</th></tr></thead>
      <tbody>
        {rows.map((r, i) => (
          <tr key={r.userId} className={r.userId === me ? 'me' : ''}>
            <td>{i + 1}</td>
            <td>{r.nickname}</td>
            <td className="bets-cell">
              {Object.entries(r.currentBets).map(([k, v]) => <span key={k} className={`tag ${k}`}>{BET_LABELS[k as BetType]} {v}</span>)}
            </td>
            <td>{r.wagered.toLocaleString()}</td>
            <td className={r.net > 0 ? 'win' : r.net < 0 ? 'lose' : ''}>{r.net > 0 ? '+' : ''}{r.net.toLocaleString()}</td>
          </tr>
        ))}
      </tbody>
    </table>
  );
}
