import type { Bets, Hall, TableSnapshot, User } from './protocol';

const TOKEN_KEY = 'baccarat.token';

export const auth = {
  get token(): string | null { try { return localStorage.getItem(TOKEN_KEY); } catch { return null; } },
  set token(v: string | null) { try { v ? localStorage.setItem(TOKEN_KEY, v) : localStorage.removeItem(TOKEN_KEY); } catch { /* ignore */ } },
};

async function req<T>(method: string, path: string, body?: unknown): Promise<T> {
  const res = await fetch(`/api${path}`, {
    method,
    headers: { 'content-type': 'application/json', ...(auth.token ? { authorization: `Bearer ${auth.token}` } : {}) },
    body: body === undefined ? undefined : JSON.stringify(body),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.error ?? res.statusText);
  return data as T;
}

export const api = {
  register: (username: string, password: string, nickname?: string) =>
    req<{ user: User; token: string }>('POST', '/auth/register', { username, password, nickname }),
  login: (username: string, password: string) => req<{ user: User; token: string }>('POST', '/auth/login', { username, password }),
  me: () => req<{ user: User }>('GET', '/me'),
  deposit: (amount: number) => req<{ balance: number }>('POST', '/me/deposit', { amount }),
  halls: () => req<{ halls: Hall[] }>('GET', '/halls'),
  table: (id: string) => req<{ table: TableSnapshot; myBets: Bets }>('GET', `/tables/${id}`),
  myBets: () => req<{ items: any[] }>('GET', '/me/bets'),
};
