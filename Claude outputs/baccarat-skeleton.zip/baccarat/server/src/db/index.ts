/**
 * 存储层：Node 22 内置 node:sqlite（零依赖，方便本地跑通）。
 * 生产环境建议换成 PostgreSQL（表结构直接对应），Redis 存牌桌实时状态。
 */
import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

export type DB = DatabaseSync;

export function openDb(path: string): DB {
  if (path !== ':memory:') mkdirSync(dirname(path), { recursive: true });
  const db = new DatabaseSync(path);
  db.exec('PRAGMA journal_mode = WAL; PRAGMA foreign_keys = ON;');
  migrate(db);
  return db;
}

function migrate(db: DB) {
  db.exec(`
    CREATE TABLE IF NOT EXISTS users (
      id            INTEGER PRIMARY KEY AUTOINCREMENT,
      username      TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      salt          TEXT NOT NULL,
      nickname      TEXT NOT NULL,
      vip_level     INTEGER NOT NULL DEFAULT 0,
      balance       REAL NOT NULL DEFAULT 0,
      role          TEXT NOT NULL DEFAULT 'player',   -- player | dealer | admin
      created_at    INTEGER NOT NULL
    );

    -- 钱包流水：每一笔余额变动
    CREATE TABLE IF NOT EXISTS transactions (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      user_id    INTEGER NOT NULL REFERENCES users(id),
      kind       TEXT NOT NULL,        -- deposit | bet | payout | refund | adjust
      amount     REAL NOT NULL,        -- 正为入账，负为出账
      balance    REAL NOT NULL,        -- 变动后余额
      ref        TEXT,                 -- round_id / 备注
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_tx_user ON transactions(user_id, id);

    -- 牌靴：每靴记录随机源指纹，供审计
    CREATE TABLE IF NOT EXISTS shoes (
      id          TEXT PRIMARY KEY,
      table_id    TEXT NOT NULL,
      fingerprint TEXT,
      deck_count  INTEGER NOT NULL,
      created_at  INTEGER NOT NULL
    );

    -- 每一局：结果 + 全部牌序
    CREATE TABLE IF NOT EXISTS rounds (
      id            TEXT PRIMARY KEY,
      table_id      TEXT NOT NULL,
      shoe_id       TEXT NOT NULL,
      round_no      INTEGER NOT NULL,
      player_cards  TEXT NOT NULL,     -- JSON
      banker_cards  TEXT NOT NULL,
      outcome       TEXT NOT NULL,
      player_total  INTEGER NOT NULL,
      banker_total  INTEGER NOT NULL,
      player_pair   INTEGER NOT NULL,
      banker_pair   INTEGER NOT NULL,
      started_at    INTEGER NOT NULL,
      settled_at    INTEGER
    );
    CREATE INDEX IF NOT EXISTS idx_rounds_table ON rounds(table_id, round_no);

    -- 注单
    CREATE TABLE IF NOT EXISTS bets (
      id         INTEGER PRIMARY KEY AUTOINCREMENT,
      round_id   TEXT NOT NULL,
      table_id   TEXT NOT NULL,
      user_id    INTEGER NOT NULL REFERENCES users(id),
      bet_type   TEXT NOT NULL,
      amount     REAL NOT NULL,
      returned   REAL,                 -- 结算后填入
      net        REAL,
      created_at INTEGER NOT NULL
    );
    CREATE INDEX IF NOT EXISTS idx_bets_round ON bets(round_id);
    CREATE INDEX IF NOT EXISTS idx_bets_user ON bets(user_id, id);
  `);
}
